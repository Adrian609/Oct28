package com.triveratravel.repository;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.stereotype.Component;

import com.triveratravel.model.Reservation;

/**
 * <p>
 * This component and its source code representation are copyright protected and
 * proprietary to Trivera Technologies, LLC., Worldwide
 *
 * This component and source code may be used for instructional and evaluation
 * purposes only. No part of this component or its source code may be sold,
 * transferred, or publicly posted, nor may it be used in a commercial or
 * production environment, without the express written consent of the Trivera
 * Technologies, Inc.
 *
 * Copyright (c) 2019 Trivera Technologies, LLC. http://www.triveratech.com
 * </p>
 * 
 * @author The Trivera Tech Team.
 */
@Component
public class ReservationRepositoryMock implements ReservationRepository {
	private AtomicInteger lastGivenResevationNumber = new AtomicInteger(1000);
	private List<Reservation> reservations = new ArrayList<>();

	@Override
	public void addReservation(Reservation reservation) {
		reservation.setId(lastGivenResevationNumber.addAndGet(1));
		reservations.add(reservation);
	}

	@Override
	public List<Reservation> findAll() {
		return reservations;
	}
	
}
