package com.triveratravel.aop;

import java.lang.reflect.Method;
import java.util.Arrays;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.triveratravel.service.InvalidCardException;

/**
 * <p>
 * This component and its source code representation are copyright protected and
 * proprietary to Trivera Technologies, LLC., Worldwide
 *
 * This component and source code may be used for instructional and evaluation
 * purposes only. No part of this component or its source code may be sold,
 * transferred, or publicly posted, nor may it be used in a commercial or
 * production environment, without the express written consent of the Trivera
 * Technologies, Inc.
 *
 * Copyright (c) 2019 Trivera Technologies, LLC. http://www.triveratech.com
 * </p>
 * 
 * @author The Trivera Tech Team.
 */
@Aspect
@Component
public class InvalidCardInterceptor {

	private static final Logger LOGGER = LoggerFactory.getLogger(InvalidCardInterceptor.class);

	@AfterThrowing(pointcut = "execution(* makePayment(..))", throwing = "invalidCardException")
	public void logInvalidCard(JoinPoint thisJoinPoint, InvalidCardException invalidCardException) {
		Method m = ((MethodSignature) thisJoinPoint.getSignature()).getMethod();
		Object[] args = thisJoinPoint.getArgs();

		LOGGER.error("Logging InvalidCardException when invoking: {} with parameters {} : {}", m.getName(),
				Arrays.deepToString(args), invalidCardException.getMessage());

	}
}
