package com.triveratravel.aop;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * <p>
 * This component and its source code representation are copyright protected and
 * proprietary to Trivera Technologies, LLC., Worldwide
 *
 * This component and source code may be used for instructional and evaluation
 * purposes only. No part of this component or its source code may be sold,
 * transferred, or publicly posted, nor may it be used in a commercial or
 * production environment, without the express written consent of the Trivera
 * Technologies, Inc.
 *
 * Copyright (c) 2019 Trivera Technologies, LLC. http://www.triveratech.com
 * </p>
 * 
 * @author The Trivera Tech Team.
 */
@Aspect
@Component
public class LoggingInterceptor {
	private static final Logger LOGGER = LoggerFactory.getLogger(InvalidCardInterceptor.class);

	// @Around("execution(* *(..))")
	@Around("execution(* com.triveratravel..*.*(..))")
	public Object around(ProceedingJoinPoint jp) throws Throwable {
		LOGGER.info("Invoking {} ", jp.getSignature());
		Object returnValue = jp.proceed();
		LOGGER.info("Returning {} from {} ", returnValue, jp.getSignature());
		return returnValue;
	}

}
