package com.triveratravel.service.repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalTime;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.triveratravel.service.model.Flight;

/**
 * <p>
 * This component and its source code representation are copyright protected and
 * proprietary to Trivera Technologies, LLC., Worldwide
 *
 * This component and source code may be used for instructional and evaluation
 * purposes only. No part of this component or its source code may be sold,
 * transferred, or publicly posted, nor may it be used in a commercial or
 * production environment, without the express written consent of the Trivera
 * Technologies, Inc.
 *
 * Copyright (c) 2019 Trivera Technologies, LLC. http://www.triveratech.com
 * </p>
 * 
 * @author The Trivera Tech Team.
 */
@Repository
public class FlightRepositoryImpl implements FlightRepository {
	@Autowired
	private JdbcTemplate template;

	@Override
	public List<Flight> findAll() {
		String sql = "SELECT * FROM DEPARTURES";
		List<Flight> result = template.query(sql, new FlightRowMapper());
		return Collections.unmodifiableList(result);
	}

	@Override
	public Flight findByFlightNumber(String flightNumber) {
		String sql = "SELECT * FROM DEPARTURES AS F WHERE F.FLIGHT_NUMBER=?";
		Object[] args = new Object[] { flightNumber };

		try {
			Flight flight = template.queryForObject(sql, args, new FlightRowMapper());
			return flight;

		} catch (IncorrectResultSizeDataAccessException e) {
			if (e.getActualSize() == 0) {
				throw new RepositoryException("No records found when trying to obtain Flight for Flight Number %s",
						flightNumber);
			}
			throw new RepositoryException("Multiple records found when trying to obtain Flight for Flight Number %s",
					flightNumber);
		}
	}

	class FlightRowMapper implements RowMapper<Flight> {
		public Flight mapRow(ResultSet rs, int rowNum) throws SQLException {
			Flight flight = new Flight();

			flight.setAirlineCode(rs.getString("AIRLINE_CODE"));
			flight.setAirlineName(rs.getString("AIRLINE_NAME"));
			flight.setCodeShare(rs.getBoolean("CODE_SHARE"));
			flight.setDestination(rs.getString("DESTINATION_NAME"));
			flight.setDestinationCode(rs.getString("DESTINATION_CODE"));
			flight.setFlightNumber(rs.getString("FLIGHT_NUMBER"));
			flight.setTerminal(rs.getString("TERMINAL"));
			flight.setTime(LocalTime.parse(rs.getString("DEPARTURE_TIME")));

			return flight;
		}

	}
}
