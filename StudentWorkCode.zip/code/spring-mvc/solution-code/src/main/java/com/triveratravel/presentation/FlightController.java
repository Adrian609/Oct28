package com.triveratravel.presentation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.triveratravel.service.AirportService;
import com.triveratravel.service.model.Flight;

/**
 * <p>
 * This component and its source code representation are copyright protected and
 * proprietary to Trivera Technologies, LLC., Worldwide
 *
 * This component and source code may be used for instructional and evaluation
 * purposes only. No part of this component or its source code may be sold,
 * transferred, or publicly posted, nor may it be used in a commercial or
 * production environment, without the express written consent of the Trivera
 * Technologies, Inc.
 *
 * Copyright (c) 2019 Trivera Technologies, LLC. http://www.triveratech.com
 * </p>
 * 
 * @author The Trivera Tech Team.
 */
@Controller
@RequestMapping("/flights")
public class FlightController {

	@Autowired
	private AirportService airportService;

	@GetMapping("viewAll")
	public String viewAll(Model model) {

		List<Flight> allFlights = airportService.getAllFlights();

		model.addAttribute("allFlights", allFlights);
		return "flights/ListAll";
	}

	@GetMapping("details")
	public String details(@RequestParam(value = "flightNumber") String flightNumber, Model model) {
		Flight flightByFlightNumber = airportService.getFlightByFlightNumber(flightNumber);

		model.addAttribute("flight", flightByFlightNumber);

		return "flights/Detail";
	}
}
