package com.triveratravel.repository;

import com.triveratravel.model.Reservation;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

/**
 * <p>
 * This component and its source code representation are copyright protected and
 * proprietary to Trivera Technologies, LLC., Worldwide
 *
 * This component and source code may be used for instructional and evaluation
 * purposes only. No part of this component or its source code may be sold,
 * transferred, or publicly posted, nor may it be used in a commercial or
 * production environment, without the express written consent of the Trivera
 * Technologies, Inc.
 *
 * Copyright (c) 2019 Trivera Technologies, LLC. http://www.triveratech.com
 * </p>
 * 
 * @author The Trivera Tech Team.
 */
public interface ReservationRepository extends JpaRepository<Reservation, Integer> {
	Reservation findOneByReservationNumber(Integer reservationNumber);

	List<Reservation> findByNameOnReservation(String nameOnReservation);

	List<Reservation> findByHotelNameAndNameOnReservationIsLike(String hotelName, String nameOnReservation);

	Integer countReservationsByHotelName(String hotelName);

	List<Reservation> findReservationsByArrivalDate(LocalDate checkIn, Sort sort);

	Page<Reservation> findReservationsByHotelName(String hotelName, Pageable pageable);
}
