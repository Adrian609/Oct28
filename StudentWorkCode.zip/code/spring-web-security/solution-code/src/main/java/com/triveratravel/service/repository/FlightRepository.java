package com.triveratravel.service.repository;


import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.triveratravel.service.model.Flight;
import com.triveratravel.service.model.FlightStatus;

import javax.transaction.Transactional;
import java.time.LocalTime;

/**
 * <p>
 * This component and its source code representation are copyright protected and
 * proprietary to Trivera Technologies, LLC., Worldwide
 * <p>
 * This component and source code may be used for instructional and evaluation
 * purposes only. No part of this component or its source code may be sold,
 * transferred, or publicly posted, nor may it be used in a commercial or
 * production environment, without the express written consent of the Trivera
 * Technologies, Inc.
 * <p>
 * Copyright (c) 2019 Trivera Technologies, LLC. http://www.triveratech.com
 * </p>
 *
 * @author The Trivera Tech Team.
 */
public interface FlightRepository extends JpaRepository<Flight, Integer> {

   Flight findByFlightNumber(String flightNumber);

   @Modifying
   @Transactional
   @Query("UPDATE #{#entityName} f SET f.flightStatus = :status "
           + "WHERE f.flightNumber = :flightNumber")
   int updateFlightStatus(@Param("flightNumber") String flightNumber, @Param("status") FlightStatus flightStatus);

   Page<Flight> findFlightsByDepartureTimeGreaterThan(LocalTime time, Pageable pageable);
}
