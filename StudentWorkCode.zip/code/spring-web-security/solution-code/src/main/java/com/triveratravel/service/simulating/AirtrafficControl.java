package com.triveratravel.service.simulating;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import com.triveratravel.service.model.Flight;
import com.triveratravel.service.model.FlightStatus;
import com.triveratravel.service.repository.FlightRepository;

import javax.annotation.PostConstruct;
import javax.transaction.Transactional;
import java.time.LocalTime;
import java.util.List;

/**
 * <p>
 * This component and its source code representation are copyright protected and
 * proprietary to Trivera Technologies, LLC., Worldwide
 * <p>
 * This component and source code may be used for instructional and evaluation
 * purposes only. No part of this component or its source code may be sold,
 * transferred, or publicly posted, nor may it be used in a commercial or
 * production environment, without the express written consent of the Trivera
 * Technologies, Inc.
 * <p>
 * Copyright (c) 2019 Trivera Technologies, LLC. http://www.triveratech.com
 * </p>
 *
 * @author The Trivera Tech Team.
 */
@Service
public class AirtrafficControl {

   private final Logger LOGGER = LoggerFactory.getLogger(AirtrafficControl.class);

   @Autowired
   private SimulatingFlightRepository simulatingRepository;

   @Autowired
   private FlightRepository flightRepository;


   @PostConstruct
   public void init() {
      //All flights with departure time < current time of which the status is still ON_TIME have been departed
      int departures = simulatingRepository.updateDepartures(LocalTime.now());
      LOGGER.info("{} flights already departed before start of application", departures);
   }

   @Scheduled(cron = "0 * * * * *")
   @Transactional
   public void updateDepartures() {
      LocalTime now = LocalTime.now();
      List<Flight> flights = simulatingRepository.findFlightsByDepartureTimeBeforeAndFlightStatus(now, FlightStatus.ON_TIME);
      if (flights.size() > 0) {
         int departures = simulatingRepository.updateDepartures(now);
         LOGGER.info("{} flights just departed", departures);
      }
   }
}
