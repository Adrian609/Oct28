package com.triveratravel.presentation;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.triveratravel.service.AirportService;
import com.triveratravel.service.model.Flight;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

/**
 * <p>
 * This component and its source code representation are copyright protected and
 * proprietary to Trivera Technologies, LLC., Worldwide
 * <p>
 * This component and source code may be used for instructional and evaluation
 * purposes only. No part of this component or its source code may be sold,
 * transferred, or publicly posted, nor may it be used in a commercial or
 * production environment, without the express written consent of the Trivera
 * Technologies, Inc.
 * <p>
 * Copyright (c) 2019 Trivera Technologies, LLC. http://www.triveratech.com
 * </p>
 *
 * @author The Trivera Tech Team.
 */
@Controller
public class FlightController {

   @Autowired
   private AirportService airportService;

   @GetMapping("management/delay")
   public ModelAndView delayFlight(@RequestParam(value = "flightNumber") String flightNumber, Model model) {
      airportService.delayFlight(flightNumber);
      ModelAndView modelAndView = new ModelAndView("management/Departures");
      return getModelAndView(modelAndView, 1);
   }

   @GetMapping("/management/page{page}")
   public ModelAndView manageFlights(@PathVariable(name = "page", required = false) Optional<Integer> page) {
      int pageNumber = page.orElse(1);
      ModelAndView modelAndView = new ModelAndView("management/Departures");
      return getModelAndView(modelAndView, pageNumber);
   }

   @GetMapping("/flightInfo")
   public String details(@RequestParam(value = "flightNumber") String flightNumber, Model model) {
      Flight flightByFlightNumber = airportService.getFlightByFlightNumber(flightNumber);
      model.addAttribute("flight", flightByFlightNumber);
      return "flights/FlightInfo";
   }

   @GetMapping("/departures/page{page}")
   public ModelAndView listDepartures(@PathVariable(name = "page", required = false) Optional<Integer> page) {
      int pageNumber = page.orElse(1);
      ModelAndView modelAndView = new ModelAndView("flights/Departures");
      return getModelAndView(modelAndView, pageNumber);
   }

   private ModelAndView getModelAndView(ModelAndView modelAndView, Integer pageNumber) {
      Page<Flight> flightPage = airportService.getDepartures(pageNumber);
      int totalPages = flightPage.getTotalPages();
      if (totalPages > 0) {
         List<Integer> pageNumbers = IntStream.rangeClosed(1, totalPages).filter(i -> i > (pageNumber - 5) && i < (pageNumber + 5)).boxed().collect(Collectors.toList());
         modelAndView.addObject("pageNumbers", pageNumbers);
      }
      modelAndView.addObject("numberOfFlightsFound", flightPage.getTotalElements());
      modelAndView.addObject("allFlights", flightPage.getContent());
      return modelAndView;
   }
}
