package com.triveratravel.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import com.triveratravel.service.model.Flight;
import com.triveratravel.service.model.FlightStatus;
import com.triveratravel.service.repository.FlightRepository;

import java.time.LocalTime;

/**
 * <p>
 * This component and its source code representation are copyright protected and
 * proprietary to Trivera Technologies, LLC., Worldwide
 * <p>
 * This component and source code may be used for instructional and evaluation
 * purposes only. No part of this component or its source code may be sold,
 * transferred, or publicly posted, nor may it be used in a commercial or
 * production environment, without the express written consent of the Trivera
 * Technologies, Inc.
 * <p>
 * Copyright (c) 2019 Trivera Technologies, LLC. http://www.triveratech.com
 * </p>
 *
 * @author The Trivera Tech Team.
 */
@Service
public class AirportServiceImpl implements AirportService {

   @Value("${flights.view.page.size}")
   private int pageSize;
   @Autowired
   private FlightRepository flightRepository;

   @Override
   public Page<Flight> getDepartures(int page) {
      PageRequest pageable = PageRequest.of(page - 1, pageSize);
      return flightRepository.findFlightsByDepartureTimeGreaterThan(LocalTime.now().minusMinutes(15), pageable);
   }

   @Override
   public Flight getFlightByFlightNumber(String flightNumber) {
      return flightRepository.findByFlightNumber(flightNumber);
   }

   @Override
   public void delayFlight(String flightNumber) {
      flightRepository.updateFlightStatus(flightNumber, FlightStatus.DELAYED);
   }
}
