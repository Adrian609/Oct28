package com.triveratravel.service;

import org.springframework.data.domain.Page;
import com.triveratravel.service.model.Flight;

/**
 * <p>
 * This component and its source code representation are copyright protected and
 * proprietary to Trivera Technologies, LLC., Worldwide
 * <p>
 * This component and source code may be used for instructional and evaluation
 * purposes only. No part of this component or its source code may be sold,
 * transferred, or publicly posted, nor may it be used in a commercial or
 * production environment, without the express written consent of the Trivera
 * Technologies, Inc.
 * <p>
 * Copyright (c) 2019 Trivera Technologies, LLC. http://www.triveratech.com
 * </p>
 *
 * @author The Trivera Tech Team.
 */
public interface AirportService {

   Page<Flight> getDepartures(int page);

   Flight getFlightByFlightNumber(String flightNumber);

   void delayFlight(String flightNumber);
}
