package com.triveratravel.service.model;

import javax.persistence.*;
import java.time.LocalTime;

/**
 * <p>
 * This component and its source code representation are copyright protected and
 * proprietary to Trivera Technologies, LLC., Worldwide
 * <p>
 * This component and source code may be used for instructional and evaluation
 * purposes only. No part of this component or its source code may be sold,
 * transferred, or publicly posted, nor may it be used in a commercial or
 * production environment, without the express written consent of the Trivera
 * Technologies, Inc.
 * <p>
 * Copyright (c) 2019 Trivera Technologies, LLC. http://www.triveratech.com
 * </p>
 *
 * @author The Trivera Tech Team.
 */
@Entity
@Table(name = "DEPARTURES")
public class Flight {
   @Id
   @Column(name = "FLIGHT_ID")
   private Integer flightId;
   @Column(name = "FLIGHT_NUMBER")
   private String flightNumber;
   @Column(name = "DESTINATION_NAME")
   private String destination;
   @Column(name = "DESTINATION_CODE")
   private String destinationCode;
   @Column(name = "AIRLINE_NAME")
   private String airlineName;
   @Column(name = "AIRLINE_CODE")
   private String airlineCode;
   @Column(name = "DEPARTURE_TIME")
   private LocalTime departureTime;
   @Column(name = "TERMINAL")
   private String terminal;
   @Column(name = "CODE_SHARE")
   private boolean codeShare;
   @Enumerated(EnumType.STRING)
   @Column(name = "FLIGHT_STATUS")
   private FlightStatus flightStatus;

   public String getFlightNumber() {
      return flightNumber;
   }

   public void setFlightNumber(String flightNumber) {
      this.flightNumber = flightNumber;
   }

   public String getDestination() {
      return destination;
   }

   public void setDestination(String destination) {
      this.destination = destination;
   }

   public String getDestinationCode() {
      return destinationCode;
   }

   public void setDestinationCode(String destinationCode) {
      this.destinationCode = destinationCode;
   }

   public String getAirlineName() {
      return airlineName;
   }

   public void setAirlineName(String airlineName) {
      this.airlineName = airlineName;
   }

   public String getAirlineCode() {
      return airlineCode;
   }

   public void setAirlineCode(String airlineCode) {
      this.airlineCode = airlineCode;
   }

   public LocalTime getDepartureTime() {
      return departureTime;
   }

   public void setDepartureTime(LocalTime departureTime) {
      this.departureTime = departureTime;
   }

   public String getTerminal() {
      return terminal;
   }

   public void setTerminal(String terminal) {
      this.terminal = terminal;
   }

   public boolean isCodeShare() {
      return codeShare;
   }

   public void setCodeShare(boolean codeShare) {
      this.codeShare = codeShare;
   }

   public FlightStatus getFlightStatus() {
      return flightStatus;
   }

   public void setFlightStatus(FlightStatus flightStatus) {
      this.flightStatus = flightStatus;
   }

   @Override
   public String toString() {
      return String.format(
              "Flight [flightNumber=%s, destination=%s, destinationCode=%s, airlineName=%s, airlineCode=%s, departureTime=%s, terminal=%s, codeShare=%s, flightStatus=%s]",
              flightNumber, destination, destinationCode, airlineName, airlineCode, departureTime, terminal, codeShare, flightStatus);
   }
}
