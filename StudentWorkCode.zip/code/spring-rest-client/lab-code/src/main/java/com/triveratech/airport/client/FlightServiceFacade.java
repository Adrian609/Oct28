package com.triveratech.airport.client;

import java.net.URI;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriTemplate;

import com.triveratech.airport.client.model.DepartureData;

/**
 * <p>
 * This component and its source code representation are copyright protected and
 * proprietary to Trivera Technologies, LLC., Worldwide
 *
 * This component and source code may be used for instructional and evaluation
 * purposes only. No part of this component or its source code may be sold,
 * transferred, or publicly posted, nor may it be used in a commercial or
 * production environment, without the express written consent of the Trivera
 * Technologies, Inc.
 *
 * Copyright (c) 2019 Trivera Technologies, LLC. http://www.triveratech.com
 * </p>
 * 
 * @author The Trivera Tech Team.
 */
@Component
public class FlightServiceFacade {

	@Value("${base.url}")
	private String baseURL;

	@Autowired
	private RestTemplate restTemplate;

	/**
	 * "/flights/departure/{flightNumber}"
	 */
	public DepartureData getFlightByFlightNumber(String flightNumber) {
		String URL = baseURL + "/flights/departure/{flightNumber}";
		return null;
	}

	/**
	 * "/flights/departures"
	 */
	public List<DepartureData> getAllFlights() {
		String URL = baseURL + "/flights/departures";


		return Collections.EMPTY_LIST;
	}

	/**
	 * "/flights/departures/{destinationCode}"
	 */
	public List<DepartureData> getFlightsDepartingTo(String destinationCode) {
		String URL = baseURL + "/flights/departures/{destinationCode}";

		return Collections.EMPTY_LIST;
	}

}
